/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_12318166303807365835_3151998091_0035479996_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0035479996", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0035479996.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0871725857_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0871725857", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0871725857.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2508353685_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2508353685", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2508353685.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3410421475_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3410421475", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3410421475.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1664674450_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1664674450", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1664674450.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1389424655_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1389424655", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1389424655.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0109991756_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0109991756", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0109991756.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1093545372_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1093545372", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1093545372.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0929451473_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0929451473", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0929451473.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1892038401_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1892038401", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1892038401.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2433828453_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2433828453", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2433828453.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3453125865_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3453125865", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3453125865.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1305646157_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1305646157", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1305646157.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1733899916_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1733899916", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1733899916.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_4231700084_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_4231700084", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_4231700084.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3241033016_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3241033016", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3241033016.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1515034048_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1515034048", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1515034048.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2682956622_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2682956622", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2682956622.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2886067497_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2886067497", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2886067497.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0966631674_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0966631674", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0966631674.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0655713422_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0655713422", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0655713422.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0141933159_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0141933159", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0141933159.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3752261964_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3752261964", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3752261964.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2919412179_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2919412179", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2919412179.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3998147537_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3998147537", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3998147537.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0736746847_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0736746847", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0736746847.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1806012253_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1806012253", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1806012253.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1211754597_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1211754597", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1211754597.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0436324290_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0436324290", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0436324290.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0644689494_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0644689494", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0644689494.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3979476467_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3979476467", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3979476467.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3205091924_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3205091924", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3205091924.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3705268078_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3705268078", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3705268078.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0427743712_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0427743712", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0427743712.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_4072764255_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_4072764255", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_4072764255.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3161902198_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3161902198", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3161902198.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2363923507_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2363923507", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2363923507.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2397161673_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2397161673", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2397161673.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2149197282_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2149197282", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2149197282.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3964253995_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3964253995", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3964253995.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3821670616_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3821670616", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3821670616.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0680969085_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0680969085", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0680969085.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3525446213_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3525446213", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3525446213.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1203392406_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1203392406", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1203392406.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1245625503_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1245625503", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1245625503.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1951728113_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1951728113", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1951728113.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1170021228_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1170021228", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1170021228.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2985443199_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2985443199", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2985443199.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0394605771_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0394605771", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0394605771.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2058284250_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2058284250", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2058284250.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3274271170_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3274271170", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3274271170.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1421244651_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1421244651", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1421244651.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1700684406_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1700684406", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1700684406.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0714184583_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0714184583", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0714184583.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2758437384_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2758437384", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2758437384.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2700696824_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2700696824", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2700696824.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3788325922_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3788325922", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3788325922.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1640846470_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1640846470", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1640846470.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1262941767_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1262941767", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1262941767.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3350880050_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3350880050", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3350880050.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_4132586927_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_4132586927", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_4132586927.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1344622107_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1344622107", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1344622107.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2792177394_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2792177394", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2792177394.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0001717574_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0001717574", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0001717574.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0320209467_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0320209467", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0320209467.didat");
}
