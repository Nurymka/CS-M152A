/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_02253721222203995675_2662658903_1841498041_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_1841498041", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_1841498041.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_3644452940_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_3644452940", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_3644452940.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_4183615812_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_4183615812", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_4183615812.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_2093507646_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_2093507646", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_2093507646.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_1882512879_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_1882512879", "isim/TEST_gate_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_1882512879.didat");
}
